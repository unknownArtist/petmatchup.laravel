<?php

class Autoloader_HardCoded {}
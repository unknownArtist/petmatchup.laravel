<?php

class Auth_Controller extends Controller {

	public function action_index()
	{
		return __FUNCTION__;
	}

	public function action_login()
	{
		return __FUNCTION__;
	}

	public function action_profile($name)
	{
		return $name;
	}

}